package sample.ordermenu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class orderController implements Initializable {
    Order order = new Order();
    @FXML
    private Tab t1;
    @FXML
    private Tab t2;
    @FXML
    private Tab t3;
    //food buttons within ordering menu
    @FXML
    private Button pizzaB1;
    @FXML
    private Button pizzaB2;
    @FXML
    private Button pizzaB3;
    @FXML
    private Button pizzaB4;
    @FXML
    private Button pizzaB5;
    @FXML
    private Button pizzaB6;
    @FXML
    private Button sidesB1;
    @FXML
    private Button sidesB2;
    @FXML
    private Button sidesB3;
    @FXML
    private Button sidesB4;
    @FXML
    private Button sidesB5;
    @FXML
    private Button sidesB6;
    @FXML
    private Button drinksB1;
    @FXML
    private Button drinksB2;
    @FXML
    private Button drinksB3;
    @FXML
    private Button drinksB4;
    @FXML
    private Button drinksB5;
    @FXML
    private Button drinksB6;
    @FXML
    private Button orderCheckoutB1;
    @FXML
    private Button orderBackB1;

    @FXML
    private void handleMenuButton(ActionEvent event) {
        Button sourceButton = (Button) event.getSource();
        if(sourceButton.equals(pizzaB1)) {
            order.addToOrder("Build your own pizza");
        } else if (sourceButton.equals(pizzaB2)){
            order.addToOrder("Cheese Pizza");
        } else if (sourceButton.equals(pizzaB3)){
            order.addToOrder("Pepperoni Pizza");
        } else if (sourceButton.equals(pizzaB4)){
            order.addToOrder("Sausage Pizza");
        } else if (sourceButton.equals(pizzaB5)){
            order.addToOrder("Hawaiian Pizza");
        } else if (sourceButton.equals(pizzaB6)){
            order.addToOrder("Vegetable Pizza");
        } else if (sourceButton.equals(sidesB1)){
            order.addToOrder("Breadsticks");
        } else if (sourceButton.equals(sidesB2)){
            order.addToOrder("Salad");
        } else if (sourceButton.equals(sidesB3)){
            order.addToOrder("Mozzarella Sticks");
        } else if (sourceButton.equals(sidesB4)){
            order.addToOrder("Chicken Nuggets");
        } else if (sourceButton.equals(sidesB5)){
            order.addToOrder("Ice cream");
        } else if (sourceButton.equals(sidesB6)){
            order.addToOrder("Cookies");
        } else if (sourceButton.equals(drinksB1)){
            order.addToOrder("Water");
        } else if (sourceButton.equals(drinksB2)){
            order.addToOrder("Fountain Drink");
        } else if (sourceButton.equals(drinksB3)){
            order.addToOrder("Lemonade");
        } else if (sourceButton.equals(drinksB4)){
            order.addToOrder("Iced Tea");
        } else if (sourceButton.equals(drinksB5)){
            order.addToOrder("Slush");
        } else if (sourceButton.equals(drinksB6)){
            order.addToOrder("Coffee");
        }
    }

    public void handleCheckout(ActionEvent event) throws IOException
    {
        order.storeOrder();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //repetitive code to change color of active tab.
        t1.setOnSelectionChanged(event -> {
            if(t1.isSelected()) {
                t1.setStyle("-fx-background-color: #850505;");
                t2.setStyle("-fx-background-color: #F3BD3F;");
                t3.setStyle("-fx-background-color: #F3BD3F;");
            } else if(t2.isSelected()) {
                t1.setStyle("-fx-background-color: #F3BD3F;");
                t2.setStyle("-fx-background-color: #850505;");
                t3.setStyle("-fx-background-color: #F3BD3F;");

            } else if(t3.isSelected()){
                t1.setStyle("-fx-background-color: #F3BD3F;");
                t2.setStyle("-fx-background-color: #F3BD3F;");
                t3.setStyle("-fx-background-color: #850505;");
            }
        });
        t2.setOnSelectionChanged(event -> {
            if(t1.isSelected()) {
                t1.setStyle("-fx-background-color: #850505;");
                t2.setStyle("-fx-background-color: #F3BD3F;");
                t3.setStyle("-fx-background-color: #F3BD3F;");
            } else if(t2.isSelected()) {
                t1.setStyle("-fx-background-color: #F3BD3F;");
                t2.setStyle("-fx-background-color: #850505;");
                t3.setStyle("-fx-background-color: #F3BD3F;");

            } else if(t3.isSelected()){
                t1.setStyle("-fx-background-color: #F3BD3F;");
                t2.setStyle("-fx-background-color: #F3BD3F;");
                t3.setStyle("-fx-background-color: #850505;");
            }
        });
        t3.setOnSelectionChanged(event -> {
            if(t1.isSelected()) {
                t1.setStyle("-fx-background-color: #850505;");
                t2.setStyle("-fx-background-color: #F3BD3F;");
                t3.setStyle("-fx-background-color: #F3BD3F;");
            } else if(t2.isSelected()) {
                t1.setStyle("-fx-background-color: #F3BD3F;");
                t2.setStyle("-fx-background-color: #850505;");
                t3.setStyle("-fx-background-color: #F3BD3F;");

            } else if(t3.isSelected()){
                t1.setStyle("-fx-background-color: #F3BD3F;");
                t2.setStyle("-fx-background-color: #F3BD3F;");
                t3.setStyle("-fx-background-color: #850505;");
            }
        });
        //end of active tab color switch
        //start of Menu buttons to add menu items to Order class
        pizzaB1.setOnAction(this::handleMenuButton);
        pizzaB2.setOnAction(this::handleMenuButton);
        pizzaB3.setOnAction(this::handleMenuButton);
        pizzaB4.setOnAction(this::handleMenuButton);
        pizzaB5.setOnAction(this::handleMenuButton);
        pizzaB6.setOnAction(this::handleMenuButton);
        sidesB1.setOnAction(this::handleMenuButton);
        sidesB2.setOnAction(this::handleMenuButton);
        sidesB3.setOnAction(this::handleMenuButton);
        sidesB4.setOnAction(this::handleMenuButton);
        sidesB5.setOnAction(this::handleMenuButton);
        sidesB6.setOnAction(this::handleMenuButton);
        drinksB1.setOnAction(this::handleMenuButton);
        drinksB2.setOnAction(this::handleMenuButton);
        drinksB3.setOnAction(this::handleMenuButton);
        drinksB4.setOnAction(this::handleMenuButton);
        drinksB5.setOnAction(this::handleMenuButton);
        drinksB6.setOnAction(this::handleMenuButton);
        //end of Menu buttons
    }
}
