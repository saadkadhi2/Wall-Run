package sample.ordermenu;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Order {

    ArrayList<String> order;
    int orderNumber;
    public Order() {
        order = new ArrayList<>();
        orderNumber = 0;
    }
    void addToOrder(String menuItem) {
        order.add(menuItem);
    }
    void printOrder() {
        for(int i = 0; i < order.size(); i++) {
            System.out.println(order.get(i));
        }
    }
    public String getOrderItem(int i) {
        return order.get(i);
    }
    void storeOrder() throws IOException {
        PrintWriter out = new PrintWriter("src/main/resources/sample/ordermenu/queue.txt");
        for(int i = 0; i < order.size(); i++) {
            out.println(order.get(i));
        }
        out.close();
    }
    void incrementOrderNum() {
        orderNumber++;
    }

}
