package sample.ordermenu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller {
    //all components used for action event declared here
    String nameUser;
    @FXML
    private Label welcomeText;
    private Stage stage;
    private Scene scene;
    private Parent root;
    //For logging in
    @FXML
    private Label incCred;
    @FXML
    private Label signedAs;
    @FXML
    private TextField userName;
    @FXML
    private TextField password;


    public void switchToLogin(ActionEvent event) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("loginScreen.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene((scene));
        stage.show();
    }

    public void switchToLoggedIn(ActionEvent event) throws IOException
    {
        boolean success = false;
        File file = new File("src/main/resources/sample/ordermenu/data.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String userInfo;
        String u = userName.getText();
        String p = password.getText();
        String fullLog =  u + "." + p;
        while ((userInfo = br.readLine()) != null){
            if(userInfo.equals( fullLog )){
                success = true;
            }
        }

        if(success == true){    //They Move on
            Parent root = FXMLLoader.load(getClass().getResource("loggedInScreen.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);

            stage.setScene((scene));
            stage.show();

        }else{                  //They must try again
            incCred.setOpacity(1.0);
        }
    }
    public void createAccount(ActionEvent event) throws IOException
    {
        File file = new File("src/main/resources/sample/ordermenu/data.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
        String userInfo = userName.getText() + "." + password.getText() + "\n" ;
        bw.write(userInfo);
        bw.flush();

        Parent root = FXMLLoader.load(getClass().getResource("titleScreen.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene((scene));
        stage.show();
        bw.close();
    }
    public void switchToOrderMenu(ActionEvent event) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("orderMenuScene.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene((scene));
        stage.show();
    }
    public void switchToCreateAccount(ActionEvent event) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("createAccountScene.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene((scene));
        stage.show();
    }




}